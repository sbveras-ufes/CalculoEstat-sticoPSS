package com.pss.calculoestatistico.service.CalculoEstatísticoService.CalculosEstatisticos;

import com.pss.calculoestatistico.model.DadoInterface;

public interface CalculoEstatistico {
    public void calcula(DadoInterface entrada);

}
